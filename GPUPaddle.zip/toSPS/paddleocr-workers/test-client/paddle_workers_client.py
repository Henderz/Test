import requests

url = "http://server-ip:port/extract-text-from-multipart-file"

payload={'dpi_x': '300',
'dpi_y': '300',
'width': '2550',
'height': '3299'}
files=[
  ('files',('page-1.png',open('C:/test/page-1.png','rb'),'image/png'))
]
headers = {}

response = requests.request("POST", url, headers=headers, data=payload, files=files)

print(response.text)
