from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    cache: str = "./cache/"    
    paddle_workers: int = 1
    api_workers: int = 1
    paddle_ocr_on_file_url: str
    host: str = "0.0.0.0"
    port_paddle_apis: int = 8080
    port_paddle_workers: int = 8081
    uvicorn_log_level: str = "info"
    use_gpu: bool = True
    language:str = 'en'


    model_config = SettingsConfigDict(env_file="./config/worker_config.env")
