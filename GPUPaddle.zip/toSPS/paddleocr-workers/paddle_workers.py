import os
import uuid
import configparser
import multiprocessing
from typing import Union, Annotated
from functools import lru_cache
from fastapi import FastAPI, File, UploadFile, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
import config
from pydantic import BaseModel
import uvicorn
import applogger
import paddle_ocr_util
import paddle_to_te


#create app from FastAPI
app = FastAPI()
VERSION = '2023-10-25'

#read logging config
LOGGER = applogger.APPLogger(__name__)
LOGGER = LOGGER.get_logger()


#set cors
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*']
)

#read config - only once
@lru_cache()
def get_settings():
    return config.Settings()

#create paddle ocr engine object
ocr_engine = paddle_ocr_util.get_ocr_engine(use_gpu=get_settings().use_gpu, language=get_settings().language)


#image params received in request
class ImageFile(BaseModel):
    file_path: Union[str, None] = None
    dpi_x: int = 300
    dpi_y: int = 300
    width: int = 2550
    height: int = 3300
    ocr_format: str = 'paddle'


@app.get("/")
@app.get("/version")
#async def read_root():
def get_version():
    return {'version': VERSION, 'application': 'paddle workers'}


@app.post("/extract-text-from-file")
@app.post("/extract-text-from-file/")
async def process_files(files: ImageFile):    
    
    file_path = None
    te_dpi = 72  # 1pt = 72dpi

    try:        
        file_path = files.file_path
        dpi_x = files.dpi_x
        dpi_y = files.dpi_y
        width = files.width
        height = files.height
        ocr_format = files.ocr_format

        # check if file_path was supplied with request
        if file_path is None:
            return {'status': False, 'message': 'file_path was not supplied'}

        # check if file exists
        if not os.path.isfile(file_path) or not os.path.exists(file_path):
            return {'status': False, 'message': 'file_path - ' + str(file_path) +' does not exist or is not a file' }

        # normalizing dpi
        dpi_x = round(float(dpi_x), 2)
        dpi_y = round(float(dpi_y), 2)        
        width = round(float(width), 2)        
        height = round(float(height), 2)

        # check if client supplied incorrect dpi or image dimensions
        if dpi_x <=0 or dpi_y <=0 or width <= 0 or height <=0:
            LOGGER.info(f'dpi_x, dpi_y, width or height is <=0 for file - {file_path}')
            return {'status': False, 'message': 'dpi_x, dpi_y, width or height is <=0'}

        LOGGER.info(f'start ocr of file - {file_path}')
        ocr_snippets = ocr_engine.ocr(file_path, cls=True)
        LOGGER.info(f'end ocr of file - {file_path}')
        ocr_snippets_first = ocr_snippets[0]                

        # return output in ocr format of paddle
        if ocr_format == 'paddle':
            LOGGER.info(f'returning paddle format for file - {file_path}')
            response = {'status': True, 'message': 'ocr output in paddle format'}
            response['paddle'] = ocr_snippets_first
            return response

        # compute dpi factor
        dpi_te_factor_x = te_dpi / dpi_x
        dpi_te_factor_y = te_dpi / dpi_y
        
        # set up img_info param
        img_info = {}
        img_info['dpi_te_factor_x'] = dpi_te_factor_x
        img_info['dpi_te_factor_y'] = dpi_te_factor_y
        img_info['width'] = width
        img_info['height'] = height
        img_info['dpi_x'] = dpi_x
        img_info['dpi_y'] = dpi_y
        
        # generate te_json
        LOGGER.info(f'generating te-json for file - {file_path}')
        te_json = paddle_to_te.form_layout_from_snippets(ocr_snippets_first, img_info)
        LOGGER.info(f'returning te-json for file - {file_path}')
        return te_json

    except Exception as e:
        if file_path:
            LOGGER.error(f" exception in get_te_from_file_multipart: {e}, in file - {file_path}")
        else:
            LOGGER.error(f" exception in get_te_from_file_multipart: {e}")
        LOGGER.error("Exception: ", exc_info=True)
        return {'status': False, 'message': 'something went wrong, please check the service /extract-text-from-file - ' + str(e)}


#commented method below saves the file into cache location and processes
""" @app.post("/extract-text-from-multipart-file")
@app.post("/extract-text-from-multipart-file/")
async def process_multipart_files(files: list[UploadFile], request: Request):        

    # initialize default values
    img_info = {}
    te_dpi = 72  # 1pt = 72dpi    
    temp_image_file = None
    ocr_format = 'te'

    try:
        form = await request.form()    

        if 'dpi_x' not in form or 'dpi_x' not in form or 'dpi_x' not in form or 'dpi_x' not in form:
            LOGGER.warn('dpi_x, dpi_y, width or height is missing in request')
        
        # read form data from request    
        dpi_x = form.get('dpi_x', 300)
        dpi_y = form.get('dpi_y', 300)
        width = form.get('width', 2550)
        height = form.get('height', 3300)
        ocr_format = form.get('ocr_format', 'te').strip()
        
        # check if files are sent in the request
        if files is None or len(files) == 0 or len(files) > 1 or (len(files) == 1 and (files[0].filename is None or len(files[0].filename.strip()) == 0)):
            response = {'status': False, 'message': 'no or more than one file present in request'}
            return response

        u_id = str(uuid.uuid4())
        cache_location = get_settings().cache
        for file_component in files:        
            LOGGER.info(f'processing file - {file_component.filename}')
            [file_name_wo_ext, ext] = os.path.splitext(file_component.filename)            
            temp_image_file = os.path.join(cache_location, u_id+ext)
            LOGGER.info(f'created cached file - {file_component.filename}')
            bytes_content = file_component.file.read()
            with open(temp_image_file,'wb') as f:
                f.write(bytes_content)
            LOGGER.info(f'created cached file - {file_component.filename} as {temp_image_file}')
        
        # normalizing dpi
        dpi_x = round(float(dpi_x), 2)
        dpi_y = round(float(dpi_y), 2)        
        width = round(float(width), 2)        
        height = round(float(height), 2)

        # check if client supplied incorrect dpi or image dimensions
        if dpi_x <=0 or dpi_y <=0 or width <= 0 or height <=0:
            LOGGER.info(f'dpi_x, dpi_y, width or height is <=0 for file - {temp_image_file}')
            response = {'status': False, 'message': 'dpi_x, dpi_y, width or height is <=0'}
            return response

        LOGGER.info(f'start ocr of file - {temp_image_file}')
        ocr_snippets = ocr_engine.ocr(temp_image_file, cls=True)
        LOGGER.info(f'end ocr of file - {temp_image_file}')
        ocr_snippets_first = ocr_snippets[0]                

        # return output in ocr format of paddle
        if ocr_format == 'paddle':
            LOGGER.info(f'returning paddle format for file - {temp_image_file}')
            response = {'status': True, 'message': 'ocr output in paddle format'}
            response['paddle'] = ocr_snippets_first
            return response

        # compute dpi factor
        dpi_te_factor_x = te_dpi / dpi_x
        dpi_te_factor_y = te_dpi / dpi_y
        
        # set up img_info param
        img_info = {}
        img_info['dpi_te_factor_x'] = dpi_te_factor_x
        img_info['dpi_te_factor_y'] = dpi_te_factor_y
        img_info['width'] = width
        img_info['height'] = height
        img_info['dpi_x'] = dpi_x
        img_info['dpi_y'] = dpi_y
        
        # generate te_json
        LOGGER.info(f'generating te-json for file - {temp_image_file}')
        te_json = paddle_to_te.form_layout_from_snippets(ocr_snippets_first, img_info)
        LOGGER.info(f'returning te-json for file - {temp_image_file}')
        return te_json
    except Exception as e:
        if temp_image_file:
            LOGGER.error(f" exception in get_te_from_file_multipart: {e}, in file - {temp_image_file}")
        else:
            LOGGER.error(f" exception in get_te_from_file_multipart: {e}")
        LOGGER.error("Exception: ", exc_info=True)
        response = {'status': False, 'message': 'something went wrong, please check the service /extract-text-from-multipart-file - ' + str(e)}
        return response
    finally:
        # delete temporary file        
        if temp_image_file and os.path.exists(temp_image_file):
            LOGGER.info(f'deleting cached file - {temp_image_file}')
            os.remove(temp_image_file)
            LOGGER.info(f'deleted cached file - {temp_image_file}') """


@app.post("/extract-text-from-multipart-file")
@app.post("/extract-text-from-multipart-file/")
async def process_multipart_bytes(files: list[UploadFile], request: Request):        

    # initialize default values
    img_info = {}
    te_dpi = 72  # 1pt = 72dpi    
    bytes_content = None
    ocr_format = 'te'
    input_file_name = ''

    try:
        form = await request.form()    

        if 'dpi_x' not in form or 'dpi_x' not in form or 'dpi_x' not in form or 'dpi_x' not in form:
            LOGGER.warn('dpi_x, dpi_y, width or height is missing in request')
        
        # read form data from request    
        dpi_x = form.get('dpi_x', 300)
        dpi_y = form.get('dpi_y', 300)
        width = form.get('width', 2550)
        height = form.get('height', 3300)
        ocr_format = form.get('ocr_format', 'te').strip()
        
        # check if files are sent in the request
        if files is None or len(files) == 0 or len(files) > 1 or (len(files) == 1 and (files[0].filename is None or len(files[0].filename.strip()) == 0)):
            response = {'status': False, 'message': 'no or more than one file present in request'}
            return response
        
        for file_component in files:        
            LOGGER.info(f'processing file - {file_component.filename}')
            [file_name_wo_ext, ext] = os.path.splitext(file_component.filename)
            bytes_content = file_component.file.read()
            input_file_name = file_component.filename
        
        # normalizing dpi
        dpi_x = round(float(dpi_x), 2)
        dpi_y = round(float(dpi_y), 2)        
        width = round(float(width), 2)        
        height = round(float(height), 2)

        # check if client supplied incorrect dpi or image dimensions
        if dpi_x <=0 or dpi_y <=0 or width <= 0 or height <=0:
            LOGGER.info(f'dpi_x, dpi_y, width or height is <=0 for file - {files[0].filename}')
            response = {'status': False, 'message': 'dpi_x, dpi_y, width or height is <=0'}
            return response

        LOGGER.info(f'start ocr of file - {input_file_name}')
        ocr_snippets = ocr_engine.ocr(bytes_content, cls=True)
        LOGGER.info(f'end ocr of file - {input_file_name}')
        ocr_snippets_first = ocr_snippets[0]                

        # return output in ocr format of paddle
        if ocr_format == 'paddle':
            LOGGER.info(f'returning paddle format for file - {input_file_name}')
            response = {'status': True, 'message': 'ocr output in paddle format'}
            response['paddle'] = ocr_snippets_first
            return response

        # compute dpi factor
        dpi_te_factor_x = te_dpi / dpi_x
        dpi_te_factor_y = te_dpi / dpi_y
        
        # set up img_info param
        img_info = {}
        img_info['dpi_te_factor_x'] = dpi_te_factor_x
        img_info['dpi_te_factor_y'] = dpi_te_factor_y
        img_info['width'] = width
        img_info['height'] = height
        img_info['dpi_x'] = dpi_x
        img_info['dpi_y'] = dpi_y
        
        # generate te_json
        LOGGER.info(f'generating te-json for file - {input_file_name}')
        te_json = paddle_to_te.form_layout_from_snippets(ocr_snippets_first, img_info)
        LOGGER.info(f'returning te-json for file - {input_file_name}')
        return te_json
    except Exception as e:
        if input_file_name:
            LOGGER.error(f" exception in process_multipart_bytes: {e}, in file - {input_file_name}")
        else:
            LOGGER.error(f" exception in process_multipart_bytes: {e}")
        LOGGER.error("Exception: ", exc_info=True)
        response = {'status': False, 'message': 'something went wrong, please check the service /extract-text-from-multipart-bytes - ' + str(e)}
        return response



@app.get("/config")
async def info(settings: Annotated[config.Settings, Depends(get_settings)]):
    return {
        "cache": settings.cache,
        "paddle_workers": settings.paddle_workers,
        "host": settings.host,
        "port_paddle_workers": settings.port_paddle_workers,
        "uvicorn_log_level": settings.uvicorn_log_level,
        "use_gpu": settings.use_gpu,
    }


if __name__ == "__main__":
    multiprocessing.freeze_support()
    host = get_settings().host
    port = get_settings().port_paddle_workers
    paddle_workers = get_settings().paddle_workers
    cache = get_settings().cache
    if not os.path.exists(cache):
        os.makedirs(cache, exist_ok=True)
    

    uvicorn.run("paddle_workers:app", host=host, port=port, log_level="info", workers=paddle_workers)