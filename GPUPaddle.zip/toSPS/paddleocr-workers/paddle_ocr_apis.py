import os
import uuid
import configparser
import requests
import multiprocessing
from typing import Union, Annotated
from functools import lru_cache
from fastapi import FastAPI, File, UploadFile, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
import config
import uvicorn
import applogger
import paddle_to_te
import pdf_utils

#import time

#create app from FastAPI
app = FastAPI()
VERSION = '2023-07-20'

#read logging config
LOGGER = applogger.APPLogger(__name__)
LOGGER = LOGGER.get_logger()

#set cors
origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=['*']
)

#read config - only once
@lru_cache()
def get_settings():
    return config.Settings()


@app.post("/extract-text-from-multipart-file")
@app.post("/extract-text-from-multipart-file/")
async def process_multipart_files(files: list[UploadFile], request: Request):        

    # initialize default values
    img_info = {}    
    temp_image_file = None
    te_dpi = 72  # 1pt = 72dpi
    
    try:
        form = await request.form()    

        if 'dpi_x' not in form or 'dpi_x' not in form or 'dpi_x' not in form or 'dpi_x' not in form:
            LOGGER.warn('dpi_x, dpi_y, width or height is missing in request')
                
        # check if files are sent in the request
        if files is None or len(files) == 0 or len(files) > 1 or (len(files) == 1 and (files[0].filename is None or len(files[0].filename.strip()) == 0)):
            response = {'status': False, 'message': 'no or more than one file present in request'}
            return response

        #save the request details along with multipart file
        img_info = await save_multipart_file(form, files)

        image_file_name = img_info['image_file_name']
        temp_image_file = img_info['image_file']
        temp_pdf_file = img_info['pdf_file']
        dpi_x = img_info['dpi_x']
        dpi_y = img_info['dpi_y']
        width = img_info['width']
        height = img_info['height']

        paddle_ocr_on_file_url = get_settings().paddle_ocr_on_file_url
        # check if image file could be saved
        if temp_image_file is None:
            LOGGER.error('could not save image file')
            return {'status': False, 'message': 'could not save image file'}
        else:
            LOGGER.info(f'saved image file - {image_file_name} as {temp_image_file}')
            request_body = {"file_path": temp_image_file, "dpi_x":dpi_x, "dpi_y": dpi_y, "width":width, "height":height, "ocr_format": "paddle"}
            #time.time.sleep(100000)
            #return "Hey"

            response = await call_paddle_worker_on_file(paddle_ocr_on_file_url, request_body)
            #time.time.sleep(100000)


            if response and response.json:
                paddle_response = response.json()
                if paddle_response and paddle_response.get('status', False) and 'paddle' in paddle_response:
                    # compute dpi factor
                    dpi_te_factor_x = te_dpi / dpi_x
                    dpi_te_factor_y = te_dpi / dpi_y
                    img_info['dpi_te_factor_x'] = dpi_te_factor_x
                    img_info['dpi_te_factor_y'] = dpi_te_factor_y
                    # generate te_json
                    LOGGER.info(f'generating te-json for file - {temp_image_file}')
                    te_json = paddle_to_te.form_layout_from_snippets(paddle_response['paddle'], img_info)
                    LOGGER.info(f'returning te-json for file - {temp_image_file}')
                    return te_json
                else:                    
                    return {'status': False, 'message': 'received incorrect response from paddle workers'}
            else:
                return {'status': False, 'message': 'received no response from paddle workers'}
    except Exception as e:
        if temp_image_file:
            LOGGER.error(f" exception in get_te_from_file_multipart: {e}, in file - {temp_image_file}")
        else:
            LOGGER.error(f" exception in get_te_from_file_multipart: {e}")
        LOGGER.error("Exception: ", exc_info=True)
        response = {'status': False, 'message': 'something went wrong, please check the service /extract-text-from-multipart-file - ' + str(e)}
        return response
    finally:
        # delete temporary file        
        if temp_image_file and os.path.exists(temp_image_file):
            LOGGER.info(f'deleting cached file - {temp_image_file}')
            os.remove(temp_image_file)
            LOGGER.info(f'deleted cached file - {temp_image_file}')
        
        if temp_pdf_file and os.path.exists(temp_pdf_file):
            LOGGER.info(f'deleting cached file - {temp_pdf_file}')
            os.remove(temp_pdf_file)
            LOGGER.info(f'deleted cached file - {temp_pdf_file}')


# invole paddle worker with file path
async def call_paddle_worker_on_file(worker_url, request_body):
    print(f"Attempting to connect to URL:{worker_url}")
    worker_response = requests.post(worker_url, json=request_body)
    return worker_response


# save files received as part of http multipart request
# could be pdf or image
async def save_multipart_file(form, files):
    
    te_dpi = 72  # 1pt = 72dpi    
    # read form data from request    
    dpi_x = form.get('dpi_x', 300)
    dpi_y = form.get('dpi_y', 300)
    width = form.get('width', 2550)
    height = form.get('height', 3300)
    ocr_format = form.get('ocr_format', 'te').strip()
    
    # normalizing dpi
    dpi_x = round(float(dpi_x), 2)
    dpi_y = round(float(dpi_y), 2)        
    width = round(float(width), 2)        
    height = round(float(height), 2)

    # compute dpi factor
    dpi_te_factor_x = te_dpi / dpi_x
    dpi_te_factor_y = te_dpi / dpi_y
    
    # set up img_info param
    img_info = {}
    img_info['dpi_te_factor_x'] = dpi_te_factor_x
    img_info['dpi_te_factor_y'] = dpi_te_factor_y
    img_info['width'] = width
    img_info['height'] = height
    img_info['dpi_x'] = dpi_x
    img_info['dpi_y'] = dpi_y
    img_info['ocr_format'] = ocr_format
    img_info['image_file_name'] = None    
    img_info['image_file'] = None    
    img_info['pdf_file'] = None    

    cache_location = get_settings().cache
    for file_component in files:
        u_id = str(uuid.uuid4())
        LOGGER.info(f'processing file - {file_component.filename}')
        [file_name_wo_ext, ext] = os.path.splitext(file_component.filename)            
        # could be pdf or png image
        temp_image_file = os.path.join(cache_location, u_id+ext)
        LOGGER.info(f'created cached file - {file_component.filename}')
        bytes_content = file_component.file.read()
        with open(temp_image_file,'wb') as f:
            f.write(bytes_content)
        if ext.lower() == '.pdf':
            img_info['pdf_file'] = temp_image_file
            temp_png_file = os.path.join(cache_location, u_id+'.png')
            pdf_to_image_info = pdf_utils.render_pdf_page_with_info(temp_image_file, temp_png_file)
            if pdf_to_image_info['status']:                
                img_info['image_file'] = temp_png_file
                img_info['dpi_te_factor_x'] = pdf_to_image_info['dpi_te_factor_x']
                img_info['dpi_te_factor_y'] = pdf_to_image_info['dpi_te_factor_y']
                img_info['width'] = pdf_to_image_info['width']
                img_info['height'] = pdf_to_image_info['height']
                img_info['dpi_x'] = pdf_to_image_info['dpi_x']
                img_info['dpi_y'] = pdf_to_image_info['dpi_y']
            else:
                LOGGER.error(f'failed to convert pdf to png for file - {file_component.filename}')
        else:
            img_info['image_file'] = temp_image_file
        
        img_info['image_file_name'] = file_component.filename
        LOGGER.info(f'created cached file - {file_component.filename} as {temp_image_file}')

    return img_info    
    

@app.get("/config")
async def info(settings: Annotated[config.Settings, Depends(get_settings)]):
    return {
        "cache": settings.cache,
        "api_workers": settings.api_workers,
        "paddle_ocr_on_file_url": settings.paddle_ocr_on_file_url,
        "host": settings.host,
        "port_paddle_apis": settings.port_paddle_apis,
        "uvicorn_log_level": settings.uvicorn_log_level,                
    }


if __name__ == "__main__":
    multiprocessing.freeze_support()
    host = get_settings().host
    port = get_settings().port_paddle_apis
    api_workers = get_settings().api_workers
    uvicorn_log_level = get_settings().uvicorn_log_level
    cache = get_settings().cache
    if not os.path.exists(cache):
        os.makedirs(cache, exist_ok=True)
    
    uvicorn.run("paddle_ocr_apis:app", host=host, port=port, log_level=uvicorn_log_level, workers=api_workers)
