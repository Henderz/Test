import re
import json


def get_words_in_poly(phrase_snippet, dpi_te_factor_x, dpi_te_factor_y):
    region_poly, phrase_info = phrase_snippet

    for i in range(4):
        region_poly[i][0] = round(region_poly[i][0] * dpi_te_factor_x, 2)
        region_poly[i][1] = round(region_poly[i][1] * dpi_te_factor_y, 2)

    # FIXME temporarily: pushing the top line down, raising the lower line
    # ... sometimes, the lower-y of upper line overlaps with upper-y of lower line
    # ... this should be handled by other pieces of code but this is a workaround.
    region_poly[0][1] = round(region_poly[0][1] + 0.5, 2) # push down slightly
    region_poly[1][1] = round(region_poly[1][1] + 0.5, 2) # push down slightly
    region_poly[2][1] = round(region_poly[2][1] - 0.5, 2) # pull up slightly
    region_poly[3][1] = round(region_poly[3][1] - 0.5, 2) # pull up slightly

    poly_lx = region_poly[0][0]
    poly_ty = region_poly[0][1]
    poly_rx = region_poly[1][0]
    poly_by = region_poly[2][1]

    rect_l = poly_lx
    rect_t = poly_ty
    rect_r = poly_rx
    rect_b = poly_by

    text, score = phrase_info
    confidence = round(score * 100, 1)

    # identify words in phrase and the regions
    match = re.finditer(r'\S+', text)
    words = []
    text_len = len(text)
    if match:
        # At least 1 word
        poly_ly = region_poly[0][1]
        poly_ry = region_poly[1][1]
        poly_lby = region_poly[3][1]
        char_dx = (poly_rx - poly_lx) / text_len
        char_dy = (poly_ry - poly_ly) / text_len
        for m in match:
            # print(f"  m: {m}")
            start, end = m.span()
            w_text = m.group()
            w_l = round(poly_lx + start * char_dx, 1)
            w_t = round(poly_ly + start * char_dy, 1)
            w_r = round(poly_lx + end * char_dx, 1)
            w_b = round(poly_lby + end * char_dy, 1)
            # print(f"  pos({w_text}): {w_l},{w_t}, {w_r},{w_b}")
            w = {"id":0,"text":w_text,"region":{"l":w_l,"t":w_t,"r":w_r,"b":w_b},"confidence":confidence,"dir":0.0}
            words.append(w)
    else:
        w = {"id":0,"text":text,"region":{"l":rect_l,"t":rect_t,"r":rect_r,"b":rect_b},"confidence":confidence,"dir":0.0}
        words.append(w)
    phrase = {"id":0,"text":text,"region":{"l":rect_l,"t":rect_t,"r":rect_r,"b":rect_b},"confidence":confidence,"dir":0.0, "words": [], "region_poly": region_poly}
    return (phrase, words)


def form_layout_from_snippets(phrase_snippets, img_info={}):
    dpi_te_factor_x = img_info.get('dpi_te_factor_x', 0.66)
    dpi_te_factor_y = img_info.get('dpi_te_factor_y', 0.66)
    img_width = img_info.get('width', 900)
    img_height = img_info.get('height', 1200)
    dpi_x = img_info.get('dpi_x', 300.0)
    dpi_y = img_info.get('dpi_y', 300.0)
    normalized_width = round(img_width * dpi_te_factor_x, 2)
    normalized_height = round(img_height * dpi_te_factor_y, 2)

    word_idx = 0
    phrase_idx = 0
    phrases = []
    words = []
    phrase_snippets.sort(key=lambda k: (k[0][0][1]))
    for phrase_snippet in phrase_snippets:
        phrase, phrase_words = get_words_in_poly(phrase_snippet, dpi_te_factor_x, dpi_te_factor_y)
        phrase_word_ids = []
        phrase_idx += 1
        phrase['id'] = phrase_idx
        phrase['words'] = phrase_word_ids
        for w in phrase_words:
            word_idx += 1
            w['id'] = word_idx
            phrase_word_ids.append(word_idx)
        #print(f"  ..p: {phrase}")
        #print(f"  ..w: {phrase_words}")
        phrases.append(phrase)
        words.extend(phrase_words)

    #print()
    #print(f"  ..ph: {phrases}")
    #print(f"  ..wo: {words}")

    ### Form lines from the phrases
    # sort phrases - left-right, top-down;  left first allows for skewed docs like receipts
    sorted_phrases = sorted(phrases, key=lambda k: (k['region'].get('l'), k['region'].get('t')))
    #print()
    #print(f"--- sorted phrases: #{len(sorted_phrases)}")
    # print(f"  ..ph: {sorted_phrases}")
    #for i, p in enumerate(sorted_phrases, start=1):
    #    print(f" . {i:2d}: {p}")

    #print()
    #print(f"--- Form lines from phrases: #{len(sorted_phrases)}")
    lines = []
    for i, p in enumerate(sorted_phrases, start=1):
        p_l = p['region'].get('l')
        p_t = p['region'].get('t')
        p_r = p['region'].get('r')
        p_b = p['region'].get('b')
        overlapping_lines = []
        for line in lines:
            l_l = line['region'].get('l')
            l_t = line['region'].get('t')
            l_r = line['region'].get('r')
            l_b = line['region'].get('b')
            if not (l_t > p_b or l_b < p_t):
                # overlap: check y-overlap
                # TODO: Ensure that x-overlap is minimal (happens due to OCR imperfections)
                # compute overlap extent
                o_extent = round(min(l_b - p_t, p_b - l_t) / (p_b - p_t), 3)
                if o_extent <= 0.5:  # TODO arbitrary threshold
                    # Not a good enough overlap
                    continue
                overlapping_lines.append((o_extent, line))
        
        ### Add phrase to appropriate line or create one
        #   Though there may be overlapping lines, we may choose to skip small overlaps
        o_l = None
        if overlapping_lines:
            #print(f"  . {i:2d}: {p} ... overlaps {overlapping_lines}")
            if len(overlapping_lines) > 1:
                sorted_overlaps = sorted(overlapping_lines, key=lambda k: k[0], reverse=True)
                top_extent, top_l = sorted_overlaps[0]
                #print(f"    - Multiple line overlaps, have to consider overlap extents! {len(overlapping_lines)}")
                #print(f"     -- {sorted_overlaps[0][0]}/{sorted_overlaps[1][0]} sorted overlaps {sorted_overlaps}")
                if top_extent > 0.5:
                    o_l = top_l
                    o_extent = top_extent
                else:
                    # Don't consider as overlapping, remains a separate 'mezzanine' line!
                    #print(f"      - Skipping despite overlaps, not sufficient overlap")
                    o_l = None
            else:
                # append phrase to line
                o_extent, o_l = overlapping_lines[0]
            
            if o_l:
                o_l['region']['r'] = p_r
                o_l['region']['t'] = p_t
                o_l['region']['b'] = p_b
                o_l['phraseList'].append(p['id'])
                o_l['wordList']['id'].extend(p['words'])
                o_l['text'] += ' ' + p['text']
                #print(f"    . {i:2d}: ... revised line {o_l}")

        if not o_l:
            line_region = {"l":-1,"t":-1,"r":-1,"b":-1}
            line_words = []
            line_phrase_ids = []
            line = {"id":0,"text":"","region":line_region,"dir":0.0,"m":0.0,"c":-0.24,"wordList":{"id":line_words},"phraseList":line_phrase_ids}
            line_region.update(p['region'])
            line['text'] = p['text']
            line['lt'] = p_t
            line_words.extend(p['words'])
            line_phrase_ids.append(p['id'])
            lines.append(line)

    ### Sort lines based on left-top
    sorted_lines = sorted(lines, key=lambda k: k.get('lt'))
    plain_text_content = []
    for line_id, line in enumerate(sorted_lines, start=1):
        line['id'] = line_id
        plain_text_content.append(line.get('text'))
    plain_text = '\n'.join(plain_text_content)

    #print()
    #print(f"--- Lines --- #{len(sorted_lines)}")
    #for line_id, line in enumerate(sorted_lines, start=1):
    #    print(f". {line_id:2d}, {line}")

    #print()
    #print(f"--- plain text --- #{len(plain_text)}")
    #print(f"{plain_text}")

    # prepare TE json structure
    te_json = {
        "status":True,"message":"text extraction complete","contentType":"IMAGE",
        "ocrEngine": "PaddleOCR",
        "plainText": plain_text,
        "structuredText":{
            "pages":[
                {
                    "id":1,"pageNo":0,"pageType":"IMAGE","dir":0,"dpiX":dpi_x,"dpiY":dpi_y,"region":{"l":0.0,"t":0.0,"r":normalized_width,"b":normalized_height}
                    , "words": words
                    , "physicalLayout": {
                        "is_sorted_lines": True
                        , "lines":sorted_lines
                        , "phrases": phrases
                    }
                }
            ]
        }
    }
    # print()
    # print(f"--- te_json --- #{len(te_json)}")
    # print(f"{te_json}")

    return te_json


if __name__ == "__main__":
    with open('d:/test/paddle/paddle_output.json') as f:
        pad_json = json.load(f)
    print(form_layout_from_snippets(pad_json))