import json
import logging
import logging.config

class APPLogger:

	def __init__(self, module_name, default_level=logging.INFO):
	
		try:
			with open('config/logging.conf', 'rt') as f:
				config = json.load(f)
			logging.config.dictConfig(config)
		except:
			logging.basicConfig(level=default_level)
		
		if module_name:
			self.logger = logging.getLogger(module_name)
		else:
			self.logger = logging.getLogger(__name__)
	
	
	def get_logger(self):
		return self.logger