import os
from enum import Enum
from PyPDF2 import PdfReader, PdfWriter
from PyPDF2.generic import NumberObject, IndirectObject, ByteStringObject
import string
import logging
import re
import string
import pypdfium2 as pdfium
import math
import applogger


LOGGER = applogger.APPLogger(__name__)
LOGGER = LOGGER.get_logger()

# valid characters allowed in windows file name
VALID_FILE_NAME_CHARS = "-_.()#$^&+=!';,@ %s%s" % (string.ascii_letters, string.digits)
PDF_PAGE_TYPE = Enum('ContentType', ['NATIVE', 'IMAGE', 'SEARCHABLE'])

# pdf - render image parameters
MAX_PAGE_WIDTH = 1870.0#2550.0
MAX_PAGE_HEIGHT = 3080.0#3300.0
MAX_RESOLUTION = 220.0#300.0
INK_JET_RESOLUTION = 200.0#220.0
BITMAP_RESOLUTION = 96.0
POINTS_PER_INCH = 72.0


# Checks if the pdf contains bookmarks
def contains_bookmarks(pdf_file):
    try:
        pdf_reader = PdfReader(pdf_file)
        outlines = pdf_reader.outlines

        if outlines is None:
            return 0
        
        if type(outlines) == list and len(outlines) > 0:
            return 1
        else:
            return 0

    except Exception as error:
        LOGGER.info(f'Exception "{error}" in reading pdf bookmarks for {pdf_file}.')
        return 0


# Extracts bookmarks from pdf file
def extract_outlines(pdf_file):
    try:
        # set level to zero
        level = 0

        pdf_reader = PdfReader(pdf_file)
        pdf_outlines = pdf_reader.outlines
        num_pdf_pages = len(pdf_reader.pages)

        # no outlines were found
        if pdf_outlines is None:
            return []
        
        if type(pdf_outlines) == list and len(pdf_outlines) > 0:
            # parse and return outline from pdf file
            outlines = []
            extract_outline_item(pdf_reader, pdf_outlines, outlines, level)

            # set sequence in which outlines are extracted
            seq_no = 1
            for outline_item in outlines:
                outline_item['seqNo'] = seq_no
                seq_no = seq_no + 1
            
            # sort outlines by page number and sequence
            outlines = sorted(outlines, key=lambda d: (d['pageNo'], d['seqNo']))

            # compute number of pages for each bookmark
            len_outlines = len(outlines)
            for i in range(0,len_outlines):
                if len_outlines > i+1:
                    outlines[i]['numberOfPages'] = outlines[i+1]['pageNo'] - outlines[i]['pageNo']
                elif len_outlines == i+1:
                    outlines[i]['numberOfPages'] = num_pdf_pages - outlines[i]['pageNo'] + 1
                
                del outlines[i]['seqNo']

            # Filter out invalid bookmarks
            filtered_outlines = []
            for outline_item in outlines:
                if ('title' in outline_item and 'pageNo' in outline_item and 'numberOfPages' in outline_item and 
                outline_item['numberOfPages'] > 0 and outline_item['pageNo']>0 and 
                outline_item['pageNo']+outline_item['numberOfPages']-1<=pdf_reader.numPages):
                    filtered_outlines.append(outline_item)

            return filtered_outlines
        else:
            # no outlines found
            return []
        
    except Exception as error:
        LOGGER.info(f'Exception "{error}" in extracting pdf bookmarks for {pdf_file}.')
        return []


# internal method
def extract_outline_item(pdf_reader, pdf_outlines, outlines, level):
    # increase bookmark level
    level = level + 1
    # check for recursive bookmarks and exit
    if (10 == level):
        return
        
    try:
        for pdf_outline in pdf_outlines:
            if pdf_outline:
                if type(pdf_outline) == list:            
                    extract_outline_item(pdf_reader, pdf_outline, outlines, level)
                else:
                    #if pypdf2 is unable to identify encoding, title appears as bytearray
                    if type(pdf_outline.title) == ByteStringObject:
                        title = pdf_outline.title.decode('utf-8').strip().strip('\x00').strip('x00')
                    else:
                        title = str(pdf_outline.title).strip()

                    title = ''.join(x for x in title if x in VALID_FILE_NAME_CHARS)
                    title = title.strip()

                    # remove all invalid windows filename characters
                    if len(title) > 0:
                        outline  = {}                    
                        outline['title'] = title
                        outline['level'] = level
                        
                        if type(pdf_outline.page) == NumberObject or type(pdf_outline.page) == int:                        
                            outline['pageNo'] = int(pdf_outline.page) + 1
                        elif type(pdf_outline.page) == IndirectObject:
                            outline['pageNo'] = PdfReader.get_destination_page_number(pdf_reader, pdf_outline) + 1
                        else:
                            outline['pageNo'] = PdfReader.get_destination_page_number(pdf_reader, pdf_outline) + 1

                        outlines.append(outline)
    except Exception as error:
        LOGGER.error('error in extract_outline_item %s', error)
        pass


# Split a pdf file based on segments provided
def split_pdf_by_segments(pdf_file, segments):
    try:                
        pdf_reader = PdfReader(pdf_file)                
        for segment in segments:
            pdf_target_file = segment['bkm_split_full_file_path']
            if not os.path.exists(pdf_target_file):
                if segment['start_page_no'] > segment['end_page_no'] or segment['start_page_no'] <= 0:
                    continue

                pdf_writer = PdfWriter()
                for i in range(segment['start_page_no']-1, segment['end_page_no']):
                    pdf_writer.add_page(pdf_reader.pages[i])

                pdf_writer.remove_links()
                with open(pdf_target_file, 'wb') as outfile_pointer:
                    pdf_writer.write(outfile_pointer)


    except Exception as error:
        LOGGER.info(f'Exception "{error}" in splitting pdf file {pdf_file}.')


# Split a pdf file into individual page files
def split_pdf(pdf_file, output_folder):
    split_files = []
    try:                
        pdf_reader = PdfReader(pdf_file)                
        num_pdf_pages = len(pdf_reader.pages)
        name, ext = os.path.splitext(os.path.split(pdf_file)[1])
        
        for i in range(0,num_pdf_pages):
            pdf_writer = PdfWriter()
            pdf_writer.add_page(pdf_reader.pages[i])
            pdf_writer.remove_links()
            output_page_file_name = name+'-'+str(i+1).zfill(4)+ext
            output_page_file = os.path.join(output_folder, output_page_file_name)
            with open(output_page_file, 'wb') as outfile_pointer:
                pdf_writer.write(outfile_pointer)
            split_files.append(output_page_file_name)

    except Exception as error:
        LOGGER.info(f'Exception "{error}" in splitting pdf file {pdf_file} into page files.')
    
    return split_files


def fetch_page_type_pypdf2(pdf_file):
    page_types = []
    try:
        pdf_reader = PdfReader(pdf_file)
        pattern = re.compile('[^A-Za-z0-9]+')
        pattern_alpha = re.compile('[^A-Za-z]+')

        for pdf_page in pdf_reader.pages:
            text_content = pdf_page.extractText()
            
            alphanums = pattern.sub('', text_content)
            alphabets = pattern_alpha.sub('', alphanums)
            words = text_content.split()

            if len(words) > 3 and len(alphanums) > 25 and len(alphabets) > 10:
                if contains_glyphless_font_pypdf2(pdf_page):
                    page_types.append(PDF_PAGE_TYPE.SEARCHABLE)                    
                else:    
                    page_types.append(PDF_PAGE_TYPE.NATIVE)
            else:
                page_types.append(PDF_PAGE_TYPE.IMAGE)

    except Exception as error:
        LOGGER.info(f'Exception "{error}" in splitting pdf file {pdf_file} into page files.')
    
    for page_type in page_types:
        print(page_type)

    return page_types


def number_of_pages(pdf_file):
    n_pages = 0

    try:
        pdf = pdfium.PdfDocument(pdf_file)
        n_pages = len(pdf)
        pdf.close()
    except Exception as error:
        LOGGER.error(f'Exception "{error}" in fetch_number_of_pages for file {pdf_file}.')
        LOGGER.error(error)
    
    return n_pages


def fetch_page_type(pdf_file):
    page_types = []
    n_pages = 0

    try:
        pdf = pdfium.PdfDocument(pdf_file)
        n_pages = len(pdf)
        pattern = re.compile('[^A-Za-z0-9]+')
        pattern_alpha = re.compile('[^A-Za-z]+')

        for pdf_page in pdf:
            text_page = pdf_page.get_textpage()
            text_content = text_page.get_text_range()
            
            alphanums = pattern.sub('', text_content)
            alphabets = pattern_alpha.sub('', alphanums)
            words = text_content.split()
            
            page_width = pdf_page.get_width()
            page_height = pdf_page.get_height()

            skip_percent = 0.25
            left = skip_percent*page_width
            top = skip_percent*page_height
            right = page_width - skip_percent*page_width
            bottom = page_height - skip_percent*page_width

            text_content_body = text_page.get_text_bounded(left = left, bottom = bottom, right=right, top=top)            
            alphanums_body = pattern.sub('', text_content_body)
            alphabets_body = pattern_alpha.sub('', alphanums_body)
            words_body = text_content_body.split()

            if len(words) > 3 and len(alphanums) > 25 and len(alphabets) > 10 and len(words_body) > 3 and len(alphanums_body) > 25 and len(alphabets_body) > 10:
                page_types.append(PDF_PAGE_TYPE.NATIVE)
            else:
                page_types.append(PDF_PAGE_TYPE.IMAGE)

    except Exception as error:
        LOGGER.error(f'Exception "{error}" in fetch_page_type for file {pdf_file}.')
        LOGGER.error(error)
        for i in range(n_pages):
            page_types.append(PDF_PAGE_TYPE.IMAGE)

    return page_types


def contains_glyphless_font_pypdf2(pdf_page):
    try:
        for fonts in pdf_page._get_fonts():
                for font in fonts:
                    if 'glyphless' in str(font).strip().lower():
                        return True        
        return False
    except Exception as error:
        LOGGER.info(f'Exception "{error}" in contains_glyphless_font.')
        return False


# Split a pdf file into individual png page files
def render_pages(pdf_file, output_folder, page_num_list=[]):
    try:
        name, ext = os.path.splitext(os.path.split(pdf_file)[1])

        pdf = pdfium.PdfDocument(pdf_file)
        n_pages = len(pdf)        
        page_indices = [i for i in range(n_pages)]        
        
        if page_num_list and len(page_num_list) >0:
            page_indices = [i-1 for i in page_num_list]
        
        for i in page_indices:
            dpi = get_rendering_dpi(pdf[i].get_width(), pdf[i].get_height())
            output_page_file = os.path.join(output_folder, name+'-'+str(i+1).zfill(4)+'.png')
            bitmap = pdf[i].render(scale = dpi/72, rotation = 0)
            image = bitmap.to_pil()
            image.save(output_page_file)
        pdf.close()
        return True
    except Exception as error:
        LOGGER.info(f'Exception "{error}" in render_pages.')
        return False

def render_page(pdf_file, png_file):
    try:
        pdf = pdfium.PdfDocument(pdf_file)        
        dpi = get_rendering_dpi(pdf[0].get_width(), pdf[0].get_height())
        bitmap = pdf[0].render(scale = dpi/72, rotation = 0)
        image = bitmap.to_pil()
        image.save(png_file)
        #pdf.close()
        return True
    except Exception as error:
        LOGGER.info(f'Exception "{error}" in render_pages.')
        return False

def render_pdf_page_with_info(pdf_file, png_file):
    result = {'status':False}    
    try:
        pdf = pdfium.PdfDocument(pdf_file)
        dpi = get_rendering_dpi(pdf[0].get_width(), pdf[0].get_height())
        bitmap = pdf[0].render(scale = dpi/72, rotation = 0)
        image = bitmap.to_pil()
        im_width, im_height = image.size
        image.save(png_file)
        image.close()
            
        pdf.close()
        
        te_dpi = 72  # 1pt = 72dpi          
    
        # set up img_info param
        result['width'] = im_width
        result['height'] = im_height
        result['dpi_x'] = dpi
        result['dpi_y'] = dpi        
        # compute dpi factor
        dpi_te_factor_x = te_dpi / dpi
        dpi_te_factor_y = te_dpi / dpi
        result['dpi_te_factor_x'] = dpi_te_factor_x
        result['dpi_te_factor_y'] = dpi_te_factor_y

        result['status'] = True
    except Exception as error:
        LOGGER.error(f'Exception "{error}" in render_pages.')
        LOGGER.error("Exception: ", exc_info=True)
        result['status'] = False
    return result

def render_thumbnail(pdf_file, png_file, max_side_in_pixels):
    try:
        pdf = pdfium.PdfDocument(pdf_file)        
        max_side = pdf[0].get_width() if pdf[0].get_width() > pdf[0].get_height() else pdf[0].get_height()
        dpi = (max_side_in_pixels*72.0)/max_side        
        bitmap = pdf[0].render(scale = dpi/72, rotation = 0)
        image = bitmap.to_pil()
        image.save(png_file)
        #pdf.close()
        return True
    except Exception as error:
        LOGGER.info(f'Exception "{error}" in render_pages.')
        return False


def get_rendering_dpi(m_box_width, m_box_height):
    try:
        if m_box_height > m_box_width:  # portrait
            max_width = MAX_PAGE_WIDTH
            max_height = MAX_PAGE_HEIGHT
        else: # landscape
            max_width = MAX_PAGE_HEIGHT
            max_height = MAX_PAGE_WIDTH
        
        if MAX_RESOLUTION*m_box_width <= max_width*BITMAP_RESOLUTION and MAX_RESOLUTION*m_box_height <= max_height*BITMAP_RESOLUTION:
            return MAX_RESOLUTION
        else:
            if INK_JET_RESOLUTION*m_box_width <= max_width*BITMAP_RESOLUTION and INK_JET_RESOLUTION*m_box_height <= max_height*BITMAP_RESOLUTION:
                return INK_JET_RESOLUTION
            else:
                dpi_x = math.ceil((max_width*BITMAP_RESOLUTION)/m_box_width)
                dpi_y = math.ceil((max_height*BITMAP_RESOLUTION)/m_box_height)
                
                if dpi_x > dpi_y:
                    dpi = dpi_y
                else:
                    dpi = dpi_x
                
                if dpi > MAX_RESOLUTION:
                    return MAX_RESOLUTION
                else:
                    if dpi<1:
                        return 1
                    else:
                        return dpi

    except Exception as error:
        LOGGER.info(f'Exception "{error}" in get_rendering_dpi.')
        return POINTS_PER_INCH


if __name__ == '__main__':
    #split_pdf('d:/test/pdftools/testpdf.PDF', 'd:/test/pdftools/split/pythonout')
    #print(PDF_PAGE_TYPE.NATIVE)
    #fetch_page_type('d:/test/pdftools/testpdf.PDF')
    #fetch_page_type('D:/test/deepapp/image/image.pdf')
    #fetch_page_type('D:/test/deepapp/image/imageSearchable.pdf')
    #fetch_page_type('D:/test/pdftools/rotate/nativedocument_270.PDF')
    #fetch_page_type('D:/test/deepapp/native/native.pdf')
    #fetch_page_type('D:/test/transformdocuments/input/LoanApplication.pdf')
    #fetch_page_type('D:/test/transformdocuments/input/jbig_appraisal_searchable.pdf')
    #fetch_page_type('D:/test/transformdocuments/input/emptyimagepdf.pdf')
    #fetch_page_type('D:/test/transformdocuments/pdfcolor/8c4cc13f-caf8-4441-b9f0-c94d3b14821e-0001.pdf')
    #fetch_page_type('D:/test/transformdocuments/failedincachePC/563_0030590053_CLOSINGPACKAGE_511851379.pdf')
    #fetch_page_type('D:/test/transformdocuments/searchable/searchable.PDF') #contains non-UTF text, all pages should be image
    #render_pages('d:/test/pdftools/testpdf.PDF', 'd:/test/pdftools/split/pythonout', [1,3])
    #render_pages('D:/test/transformdocuments/input/test_jpeg2000.pdf', 'd:/test/pdftools/split/pythonout', [])
    #render_pages('D:/test/deepapp/largepage/0021955463_LoanApplication.pdf', 'd:/test/pdftools/split/pythonout', [])    
    number_of_pages('D:/test/deepapp/image/image.pdf')
    number_of_pages('D:/test/deepapp/image/imageSearchable.pdf')
    number_of_pages('D:/test/pdftools/rotate/nativedocument_270.PDF')
    number_of_pages('D:/test/deepapp/native/native.pdf')
    number_of_pages('D:/test/transformdocuments/input/LoanApplication.pdf')
    number_of_pages('D:/test/transformdocuments/input/jbig_appraisal_searchable.pdf')
    number_of_pages('D:/test/transformdocuments/input/emptyimagepdf.pdf')
    number_of_pages('D:/test/transformdocuments/pdfcolor/8c4cc13f-caf8-4441-b9f0-c94d3b14821e-0001.pdf')
    number_of_pages('D:/test/transformdocuments/failedincachePC/563_0030590053_CLOSINGPACKAGE_511851379.pdf')
    number_of_pages('D:/test/transformdocuments/searchable/searchable.PDF') 
