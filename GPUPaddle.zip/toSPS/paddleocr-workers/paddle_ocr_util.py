import os
import pathlib
import requests
import importlib
from paddleocr import PaddleOCR

paddle_models_dir = "c:/paddle/.paddleocr/"
det_model_dir = f"{paddle_models_dir}/whl/det/en/en_PP-OCRv3_det_infer"
rec_model_dir = f"{paddle_models_dir}/whl/rec/en/en_PP-OCRv3_rec_infer"
cls_model_dir = f"{paddle_models_dir}/whl/cls/ch_ppocr_mobile_v2.0_cls_infer"

resource_pkg = "resources"
resources_path = os.path.join(os.path.dirname(__file__), '..', 'resources')
res_img_path = "images/sample_note_page.png"

# default config
default_ocr_config = {
    "use_gpu": False,
    "use_ocr_service": False,
    "ocr_service_url": "http://localhost:6061/ocr_image_data"
}
class PaddleOCRConfig:
    use_gpu = False
    use_ocr_service = False
    ocr_service_url = "http://localhost:6061/ocr_image_data"
default_ocr_service_url = "http://localhost:6061/ocr_image_data"
default_ocr_service_url = "http://10.81.61.105:6061/ocr_image_data"


def get_sample_image_path():
    print(f"resources_path={resources_path}")
    img_res_ref = importlib.resources.files(resource_pkg) / res_img_path
    return img_res_ref

def get_sample_image_data():
    print(f"resources_path={resources_path}")
    img_res_ref = importlib.resources.files(resource_pkg) / res_img_path
    # print(f"res_ref: {img_res_ref}")
    img_data = None
    with importlib.resources.as_file(img_res_ref) as img_path:
        with open(img_path, 'rb') as f:
            img_data = f.read()
            print(f"data len({img_res_ref}): {len(img_data)}")
    return img_data

def get_paddle_models_resources(language):
    default_paddle_models_dir = "c:/paddle/.paddleocr"
    paddle_models_dir = default_paddle_models_dir
    if not os.path.isdir(paddle_models_dir):
        # Check home dir
        home = str(pathlib.Path.home())
        paddle_models_dir = f"{home}/.paddleocr"
    det_model_dir = f"{paddle_models_dir}/whl/det/en/en_PP-OCRv3_det_infer"
    if language == 'en':
        rec_model_dir = f"{paddle_models_dir}/whl/rec/en/en_PP-OCRv3_rec_infer"
    elif language == 'german' or language == 'latin':
        rec_model_dir = f"{paddle_models_dir}/whl/rec/latin/latin_PP-OCRv3_rec_infer"
    else:
        rec_model_dir = f"{paddle_models_dir}/whl/rec/en/en_PP-OCRv3_rec_infer"

    cls_model_dir = f"{paddle_models_dir}/whl/cls/ch_ppocr_mobile_v2.0_cls_infer"
    print(f"  .  paddle_models_resources: {(det_model_dir, rec_model_dir, cls_model_dir)}")
    return (det_model_dir, rec_model_dir, cls_model_dir)

ocr_engine = None
ocr_engine_cpu = None
def get_ocr_engine(use_gpu=True, language='en'):
    global ocr_engine
    global ocr_engine_cpu
    if use_gpu:
        if not ocr_engine:
            # ocr_engine = PaddleOCR(use_angle_cls=True, lang='en', use_gpu=True) # need to run only once to download and load model into memory
            det_model_dir, rec_model_dir, cls_model_dir = get_paddle_models_resources(language)
            ocr_engine = PaddleOCR(use_gpu=use_gpu, use_angle_cls=True, use_space_char=True, lang=language, det_model_dir=det_model_dir, rec_model_dir=rec_model_dir, cls_model_dir=cls_model_dir, show_log = False)
        return ocr_engine
    else:
        if not ocr_engine_cpu:
            # ocr_engine_cpu = PaddleOCR(use_angle_cls=True, lang='en', use_gpu=True) # need to run only once to download and load model into memory
            det_model_dir, rec_model_dir, cls_model_dir = get_paddle_models_resources(language)
            ocr_engine_cpu = PaddleOCR(use_gpu=use_gpu, use_angle_cls=True, use_space_char=True, lang=language, det_model_dir=det_model_dir, rec_model_dir=rec_model_dir, cls_model_dir=cls_model_dir, show_log = False)
        return ocr_engine_cpu

def get_ocr_snippets(img_info, use_gpu=True, use_ocr_service=True, ocr_service_url=None):
    if not use_ocr_service:
        ocr_engine = get_ocr_engine() # need to run only once to download and load model into memory
        img_path = img_info  # img_info is a path, not bytes
        ocr_snippets = ocr_engine.ocr(img_path, cls=True)
    else:
        ocr_snippets = []
        if not ocr_service_url:
            # use defaults
            ocr_service_url = default_ocr_service_url
        if not ocr_service_url:
            print(f"WARN: OCR Service not available! ocr_service_url not defined!!")
        else:
            if not isinstance(img_info, bytes):
                data = None
                img_path = img_info  # img_info is a path, not bytes
                ocr_engine = get_ocr_engine()
                ocr_snippets = ocr_engine.ocr(img_path, cls=True)
                with open(img_path, 'rb') as f:
                    data = f.read()
            else:
                data = img_info
            if data:
                res = requests.post(url=ocr_service_url,
                                data=data,
                                headers={'Content-Type': 'application/octet-stream'})
                ocr_res = res.json()
            ocr_snippets = ocr_res.get('snippets', [])
    return ocr_snippets
